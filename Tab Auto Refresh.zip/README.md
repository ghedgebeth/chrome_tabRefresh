# chrome_tabRefresh
Auto Refreshes Selected Chrome Tabs

How to Use
Click the Tab Auto Refresh icon in your Chrome toolbar.
(May want to manually pin it to the tool bar for easy access)

You’ll see a list of your open tabs (that support refreshing).

For each tab:

Enable Refresh using the toggle switch.

Set Refresh Rate using the slider (30 seconds to 5 minutes, in 30-second steps).

The tab will now automatically reload at the chosen interval — even if it's in the background.

To disable refresh, simply toggle the switch off.

Settings persist even if you close the browser or restart your computer.
